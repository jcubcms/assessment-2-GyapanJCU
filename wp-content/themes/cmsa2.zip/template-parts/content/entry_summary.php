<?php
/**
 * Template part for displaying a post's summary
 *
 * @package cmsa2
 */

namespace WP_Rig\WP_Rig;

?>

<div class="entry-summary">
	<?php the_excerpt(); ?>
</div><!-- .entry-summary -->
